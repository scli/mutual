#ifndef _MIC_MATH_H_
#define _MIC_MATH_H_

int min(int x, int y);
int max(int x, int y);

//create a permutation of integers 0 to n-1
int* permutation(int n); 



#endif

