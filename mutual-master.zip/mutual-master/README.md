# mutual
c++ code for mutual information calculation. 
The input file should have the cvs format. It contains a matrix of size m time n; 
we assume n replications, each contains m features.
the output will be a n by n matrix.


The running time should be O(nlogn).
